package com.nirexion.glassx.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigCodecTest {
    private val bundle = ConfigBundle(
        listOf(ProfileData("Rush; ñ=1", SensitivityValues(80, 70, 60, 50, 40, 90), "line1\nline2 ; = %")),
        mapOf("haptics" to "false", "difficulty" to "HARD")
    )

    @Test fun roundTrip() {
        val r = ConfigCodec.decode(ConfigCodec.encode(bundle))
        assertTrue(r is DecodeResult.Success)
        assertEquals(bundle, (r as DecodeResult.Success).bundle)
    }

    @Test fun rejectsMissingHeader() {
        assertTrue(ConfigCodec.decode("hello") is DecodeResult.Failure)
    }

    @Test fun rejectsNonNumeric() {
        val text = "${ConfigCodec.HEADER}\nprofile=A;x;1;1;1;1;1;"
        assertTrue(ConfigCodec.decode(text) is DecodeResult.Failure)
    }

    @Test fun clampsOutOfRange() {
        val text = "${ConfigCodec.HEADER}\nprofile=A;500;-4;1;1;1;1;"
        val b = (ConfigCodec.decode(text) as DecodeResult.Success).bundle
        assertEquals(100, b.profiles[0].values.general)
        assertEquals(0, b.profiles[0].values.redDot)
    }

    @Test fun rejectsInvalidSettingAndIgnoresUnknown() {
        assertTrue(ConfigCodec.decode("${ConfigCodec.HEADER}\nsetting.haptics=maybe") is DecodeResult.Failure)
        val ok = ConfigCodec.decode("${ConfigCodec.HEADER}\nsetting.unknown=1") as DecodeResult.Success
        assertTrue(ok.bundle.settings.isEmpty())
    }
}
