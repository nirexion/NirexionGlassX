package com.nirexion.glassx.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SensitivityAdvisorTest {
    private val base = SensitivityValues(70, 65, 60, 55, 40, 60)

    @Test fun noDataKeepsValues() {
        assertEquals(base, SensitivityAdvisor.recommend(base, emptyList()).values)
        assertEquals(base, SensitivityAdvisor.recommend(base, listOf(SessionSummary(10f, 400f, 3))).values)
    }

    @Test fun lowAccuracyLowersValues() {
        val r = SensitivityAdvisor.recommend(base, listOf(SessionSummary(30f, 500f, 40)))
        assertTrue(r.values.general < base.general)
        assertEquals(62, r.values.general)
    }

    @Test fun highAccuracySlowReactionRaisesValues() {
        val r = SensitivityAdvisor.recommend(base, listOf(SessionSummary(80f, 700f, 40)))
        assertEquals(75, r.values.general)
    }

    @Test fun resultIsClamped() {
        val r = SensitivityAdvisor.recommend(SensitivityValues(2, 2, 2, 2, 2, 2), listOf(SessionSummary(20f, 400f, 30)))
        assertTrue(r.values.general >= 0)
    }
}
