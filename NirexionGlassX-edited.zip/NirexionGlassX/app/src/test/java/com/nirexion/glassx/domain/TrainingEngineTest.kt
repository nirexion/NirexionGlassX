package com.nirexion.glassx.domain

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingEngineTest {
    private fun engine(d: Difficulty = Difficulty.EASY) =
        TrainingEngine(1000f, 1000f, d, density = 1f, random = Random(7))

    @Test fun spawnsATargetOnFirstUpdate() {
        val e = engine(); e.update(0)
        assertEquals(1, e.targets.size)
    }

    @Test fun hitIsDetectedAndReactionMeasured() {
        val e = engine(); e.update(0)
        val t = e.targets.first()
        assertTrue(e.tap(t.x, t.y, 250))
        val s = e.stats()
        assertEquals(1, s.hits); assertEquals(1, s.shots)
        assertEquals(250f, s.avgReactionMs, 0.001f)
        assertEquals(175, s.score)
    }

    @Test fun missCountsAgainstAccuracy() {
        val e = engine(); e.update(0)
        val t = e.targets.first()
        assertFalse(e.tap(t.x + 300f, t.y, 100))
        assertTrue(e.tap(t.x, t.y, 200))
        assertEquals(50f, e.stats().accuracy, 0.001f)
    }

    @Test fun targetsExpire() {
        val e = engine(); e.update(0)
        e.update(Difficulty.EASY.lifetimeMs + 1)
        assertEquals(1, e.expired)
    }

    @Test fun tapsAfterFinishAreIgnored() {
        val e = engine(); e.update(0)
        val t = e.targets.first()
        assertTrue(e.isFinished(60_000))
        assertFalse(e.tap(t.x, t.y, 60_000))
        assertEquals(0, e.shots)
    }

    @Test fun targetsStayInsideArena() {
        val e = engine(Difficulty.HARD)
        var now = 0L
        repeat(500) { e.update(now); now += 16 }
        e.targets.forEach {
            assertTrue(it.x in 0f..1000f); assertTrue(it.y in 0f..1000f)
        }
    }
}
