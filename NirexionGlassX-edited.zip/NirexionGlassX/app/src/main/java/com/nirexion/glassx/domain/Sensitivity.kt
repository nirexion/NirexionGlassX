package com.nirexion.glassx.domain

import kotlin.math.roundToInt

/** Free Fire MAX sensitivity sliders range 0..100. Values here are notes the player enters by hand. */
data class SensitivityValues(
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val awm: Int,
    val camera: Int
) {
    fun clamped() = SensitivityValues(
        general.coerceIn(0, 100), redDot.coerceIn(0, 100), scope2x.coerceIn(0, 100),
        scope4x.coerceIn(0, 100), awm.coerceIn(0, 100), camera.coerceIn(0, 100)
    )

    companion object {
        val DEFAULT = SensitivityValues(70, 65, 60, 55, 40, 60)
    }
}

data class SessionSummary(val accuracy: Float, val avgReactionMs: Float, val shots: Int)

data class Recommendation(val values: SensitivityValues, val summary: String)

/**
 * A simple heuristic over the player's arena results. It is a starting point for manual
 * experimentation, not a validated or in-game measurement.
 */
object SensitivityAdvisor {
    const val MIN_SHOTS = 10
    const val MAX_SESSIONS = 5

    fun recommend(base: SensitivityValues, recent: List<SessionSummary>): Recommendation {
        val usable = recent.filter { it.shots >= MIN_SHOTS }.take(MAX_SESSIONS)
        if (usable.isEmpty()) {
            return Recommendation(
                base,
                "Not enough arena data yet. Play at least one session with $MIN_SHOTS or more shots."
            )
        }
        val acc = usable.map { it.accuracy }.average().toFloat()
        val react = usable.map { it.avgReactionMs }.filter { it > 0f }.let { if (it.isEmpty()) 0f else it.average().toFloat() }
        val delta = when {
            acc < 40f -> -8
            acc < 55f -> -4
            acc > 75f && react > 600f -> 5
            else -> 0
        }
        fun adj(v: Int, factor: Float) = (v + delta * factor).roundToInt()
        val out = SensitivityValues(
            adj(base.general, 1f), adj(base.redDot, 1f), adj(base.scope2x, 0.75f),
            adj(base.scope4x, 0.75f), adj(base.awm, 0.5f), adj(base.camera, 1f)
        ).clamped()
        val msg = when {
            delta < 0 -> "Accuracy averaged %.0f%% over %d session(s), so slightly lower values may help control."
            delta > 0 -> "Accuracy is high (%.0f%%) but target-acquisition is slow (%.0f ms), so slightly higher values may help."
            else -> "Accuracy averaged %.0f%% over %d session(s). Your current values look balanced for this data."
        }
        val text = when {
            delta > 0 -> msg.format(acc, react)
            else -> msg.format(acc, usable.size)
        }
        return Recommendation(out, text + " Treat this as a suggestion and enter the values manually in the game.")
    }
}
