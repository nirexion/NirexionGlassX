package com.nirexion.glassx.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nirexion.glassx.data.AppSettings
import com.nirexion.glassx.data.ProfileEntity
import com.nirexion.glassx.data.SessionEntity
import com.nirexion.glassx.domain.SensitivityAdvisor
import com.nirexion.glassx.domain.SensitivityValues
import com.nirexion.glassx.domain.SessionSummary
import com.nirexion.glassx.ui.MainViewModel
import com.nirexion.glassx.ui.theme.GlassCard
import com.nirexion.glassx.ui.theme.GlassColors
import com.nirexion.glassx.ui.theme.GlassSlider
import com.nirexion.glassx.ui.theme.GlassTextField
import com.nirexion.glassx.ui.theme.NeonButton
import com.nirexion.glassx.ui.theme.SectionTitle

private data class Draft(val id: Long, val name: String, val values: SensitivityValues, val notes: String)

@Composable
fun ProfilesScreen(settings: AppSettings, profiles: List<ProfileEntity>, sessions: List<SessionEntity>, vm: MainViewModel) {
    var draft by remember { mutableStateOf<Draft?>(null) }
    var advice by remember { mutableStateOf<String?>(null) }
    var toDelete by remember { mutableStateOf<ProfileEntity?>(null) }
    val active = profiles.firstOrNull { it.id == settings.activeProfileId }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Sensitivity profiles", color = GlassColors.Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "These are saved notes. NIREXION GLASS X cannot change Free Fire MAX settings. " +
                    "Copy the values by hand into the game's Settings > Sensitivity screen.",
                color = GlassColors.Dim, fontSize = 12.sp
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("New profile", {
                draft = Draft(0, "", SensitivityValues.DEFAULT, ""); advice = null
            }, Modifier.weight(1f))
            NeonButton("Suggest from arena", {
                val base = draft?.values ?: active?.toValues() ?: SensitivityValues.DEFAULT
                val rec = SensitivityAdvisor.recommend(
                    base, sessions.take(SensitivityAdvisor.MAX_SESSIONS).map { SessionSummary(it.accuracy, it.avgReactionMs, it.shots) }
                )
                advice = rec.summary
                draft = (draft ?: Draft(0, "Arena suggestion", base, "")).copy(values = rec.values)
            }, Modifier.weight(1f), accent = GlassColors.NeonAlt)
        }
        advice?.let {
            GlassCard(Modifier.fillMaxWidth()) {
                SectionTitle("Suggestion")
                Spacer(Modifier.height(6.dp))
                Text(it, color = GlassColors.Ink, fontSize = 13.sp)
            }
        }
        draft?.let { d ->
            GlassCard(Modifier.fillMaxWidth()) {
                SectionTitle(if (d.id == 0L) "New profile" else "Edit profile")
                Spacer(Modifier.height(8.dp))
                GlassTextField(d.name, { draft = d.copy(name = it.take(40)) }, "Profile name", Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                GlassSlider("General", d.values.general) { draft = d.copy(values = d.values.copy(general = it)) }
                GlassSlider("Red Dot", d.values.redDot) { draft = d.copy(values = d.values.copy(redDot = it)) }
                GlassSlider("2x Scope", d.values.scope2x) { draft = d.copy(values = d.values.copy(scope2x = it)) }
                GlassSlider("4x Scope", d.values.scope4x) { draft = d.copy(values = d.values.copy(scope4x = it)) }
                GlassSlider("AWM Scope", d.values.awm) { draft = d.copy(values = d.values.copy(awm = it)) }
                GlassSlider("Free Look / Camera", d.values.camera) { draft = d.copy(values = d.values.copy(camera = it)) }
                GlassTextField(d.notes, { draft = d.copy(notes = it.take(500)) }, "Notes", Modifier.fillMaxWidth(), singleLine = false)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NeonButton("Save", {
                        if (d.name.isBlank()) vm.toast("Give the profile a name first")
                        else { vm.saveProfile(d.id, d.name, d.values, d.notes); draft = null; advice = null }
                    }, Modifier.weight(1f), accent = GlassColors.Good)
                    NeonButton("Cancel", { draft = null }, Modifier.weight(1f), accent = GlassColors.Dim)
                }
            }
        }
        if (profiles.isEmpty()) {
            Text("No profiles yet. Create one above.", color = GlassColors.Dim, fontSize = 13.sp)
        }
        profiles.forEach { p ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.name, color = GlassColors.Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (p.id == settings.activeProfileId) Text("ACTIVE", color = GlassColors.Good, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "G ${p.general} · RD ${p.redDot} · 2x ${p.scope2x} · 4x ${p.scope4x} · AWM ${p.awm} · Cam ${p.camera}",
                    color = GlassColors.Dim, fontSize = 12.sp
                )
                if (p.notes.isNotBlank()) Text(p.notes, color = GlassColors.Dim, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Edit", {
                        draft = Draft(p.id, p.name, p.toValues(), p.notes); advice = null
                    }, Modifier.weight(1f))
                    NeonButton("Set active", { vm.setActiveProfile(p.id) }, Modifier.weight(1f), enabled = p.id != settings.activeProfileId, accent = GlassColors.Good)
                    NeonButton("Delete", { toDelete = p }, Modifier.weight(1f), accent = GlassColors.Bad)
                }
            }
        }
    }
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = GlassColors.Deep,
            title = { Text("Delete profile?", color = GlassColors.Ink) },
            text = { Text("“${p.name}” will be removed from this device.", color = GlassColors.Dim) },
            confirmButton = { TextButton({ vm.deleteProfile(p.id); toDelete = null }) { Text("Delete", color = GlassColors.Bad) } },
            dismissButton = { TextButton({ toDelete = null }) { Text("Cancel", color = GlassColors.Neon) } }
        )
    }
}
