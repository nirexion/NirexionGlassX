package com.nirexion.glassx.ui.screens

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nirexion.glassx.data.AppSettings
import com.nirexion.glassx.data.SessionEntity
import com.nirexion.glassx.domain.Difficulty
import com.nirexion.glassx.domain.SessionStats
import com.nirexion.glassx.domain.TrainingEngine
import com.nirexion.glassx.ui.theme.GlassCard
import com.nirexion.glassx.ui.theme.GlassColors
import com.nirexion.glassx.ui.theme.NeonButton
import com.nirexion.glassx.ui.theme.SectionTitle

private enum class Phase { SETUP, RUNNING, DONE }

@Composable
fun ArenaScreen(
    settings: AppSettings,
    onSaveSession: (SessionEntity) -> Unit,
    onDifficulty: (Difficulty) -> Unit,
    onImmersive: (Boolean) -> Unit,
    onShowResults: () -> Unit
) {
    var phase by remember { mutableStateOf(Phase.SETUP) }
    var result by remember { mutableStateOf<SessionStats?>(null) }
    val difficulty = settings.difficulty
    DisposableEffect(Unit) { onDispose { onImmersive(false) } }

    when (phase) {
        Phase.SETUP -> Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Training arena", color = GlassColors.Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
            GlassCard(Modifier.fillMaxWidth()) {
                SectionTitle("Difficulty")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Difficulty.values().forEach { d ->
                        NeonButton(d.label, { onDifficulty(d) }, Modifier.weight(1f), accent = if (d == difficulty) GlassColors.Neon else GlassColors.Dim)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "60 seconds. Tap targets as they appear. Smaller, faster targets on higher levels. " +
                        "Time-to-hit is measured from a target appearing to your tap. This arena is self-contained and unrelated to the game.",
                    color = GlassColors.Dim, fontSize = 12.sp
                )
            }
            NeonButton("Start session", { onImmersive(true); phase = Phase.RUNNING }, Modifier.fillMaxWidth(), accent = GlassColors.Good)
        }
        Phase.RUNNING -> ArenaRun(difficulty, settings.haptics) { e, elapsed ->
            val st = e.stats()
            if (st.shots > 0) {
                onSaveSession(
                    SessionEntity(
                        startedAt = System.currentTimeMillis() - elapsed, difficulty = difficulty.name, shots = st.shots,
                        hits = st.hits, expired = st.expired, accuracy = st.accuracy, avgReactionMs = st.avgReactionMs,
                        bestReactionMs = st.bestReactionMs, score = st.score, durationMs = elapsed
                    )
                )
                result = st
            } else result = null
            onImmersive(false)
            phase = Phase.DONE
        }
        Phase.DONE -> Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Session complete", color = GlassColors.Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
            GlassCard(Modifier.fillMaxWidth()) {
                val r = result
                if (r == null) {
                    Text("No shots were recorded, so this session was not saved.", color = GlassColors.Dim)
                } else {
                    ResultLine("Score", "${r.score}")
                    ResultLine("Accuracy", "%.0f%% (%d/%d)".format(r.accuracy, r.hits, r.shots))
                    ResultLine("Avg time-to-hit", if (r.hits > 0) "%.0f ms".format(r.avgReactionMs) else "—")
                    ResultLine("Best time-to-hit", if (r.hits > 0) "%.0f ms".format(r.bestReactionMs) else "—")
                    ResultLine("Targets missed (expired)", "${r.expired}")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonButton("Play again", { phase = Phase.SETUP }, Modifier.weight(1f), accent = GlassColors.Good)
                NeonButton("View stats", onShowResults, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ResultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = GlassColors.Dim, fontSize = 14.sp)
        Text(value, color = GlassColors.Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ArenaRun(difficulty: Difficulty, haptics: Boolean, onFinished: (TrainingEngine, Long) -> Unit) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    var engine by remember { mutableStateOf<TrainingEngine?>(null) }
    var frame by remember { mutableLongStateOf(0L) }
    var abort by remember { mutableStateOf(false) }
    val density = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current
    BackHandler { abort = true }

    LaunchedEffect(size) {
        if (size.width > 0 && size.height > 0) {
            val t0 = SystemClock.uptimeMillis()
            val e = TrainingEngine(size.width.toFloat(), size.height.toFloat(), difficulty, density, startMs = t0)
            engine = e
            while (true) {
                androidx.compose.runtime.withFrameNanos { }
                val now = SystemClock.uptimeMillis()
                e.update(now)
                frame = now
                if (e.isFinished(now) || abort) {
                    onFinished(e, (now - t0).coerceAtMost(e.durationMs))
                    break
                }
            }
        }
    }

    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectTapGestures(onPress = { off ->
                    val e = engine
                    if (e != null && e.tap(off.x, off.y, SystemClock.uptimeMillis()) && haptics) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                })
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val now = frame
            val e = engine ?: return@Canvas
            e.targets.forEach { t ->
                val c = Offset(t.x, t.y)
                val left = (1f - (now - t.spawnedAtMs) / difficulty.lifetimeMs.toFloat()).coerceIn(0f, 1f)
                drawCircle(GlassColors.Neon.copy(alpha = 0.18f), t.radius * 1.4f, c)
                drawCircle(
                    Brush.radialGradient(listOf(GlassColors.Ink, GlassColors.Neon, GlassColors.NeonAlt), center = c, radius = t.radius),
                    t.radius, c
                )
                drawCircle(GlassColors.Void.copy(alpha = 0.7f), t.radius * 0.35f, c)
                drawArc(
                    GlassColors.Pink, -90f, 360f * left, false,
                    Offset(t.x - t.radius * 1.2f, t.y - t.radius * 1.2f), Size(t.radius * 2.4f, t.radius * 2.4f),
                    style = Stroke(3f)
                )
            }
        }
        engine?.let { e ->
            val st = e.stats()
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text("⏱ ${e.remainingMs(frame) / 1000}s", color = GlassColors.Ink, fontWeight = FontWeight.Bold)
                Text("${st.hits}/${st.shots}", color = GlassColors.Ink, fontWeight = FontWeight.Bold)
                Text("★ ${st.score}", color = GlassColors.Neon, fontWeight = FontWeight.Bold)
                NeonButton("End", { abort = true }, accent = GlassColors.Bad)
            }
        }
    }
}
