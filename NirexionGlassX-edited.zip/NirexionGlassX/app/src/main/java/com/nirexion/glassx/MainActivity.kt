package com.nirexion.glassx

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.nirexion.glassx.overlay.OverlayService
import com.nirexion.glassx.ui.GlassApp
import com.nirexion.glassx.ui.HostActions
import com.nirexion.glassx.ui.HostStatus
import com.nirexion.glassx.ui.MainViewModel
import com.nirexion.glassx.util.GameLauncher
import com.nirexion.glassx.util.LaunchResult
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var status by mutableStateOf(HostStatus())
    private var pendingRoute by mutableStateOf<String?>(null)
    private var awaitingOverlayGrant = false

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            refreshStatus()
            if (!granted) vm.toast("Notifications denied. The panel still works, but its status notification may be hidden.")
            startOverlay()
        }
    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            if (uri != null) vm.exportTo(contentResolver, uri) else vm.toast("Export cancelled")
        }
    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.importFrom(contentResolver, uri) else vm.toast("Import cancelled")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        pendingRoute = intent?.getStringExtra(EXTRA_ROUTE)
        refreshStatus()

        // Restore the overlay if the user left it enabled and the permission is still granted.
        lifecycleScope.launch {
            val wanted = (application as GlassXApp).settingsRepository.settings.first().overlayEnabled
            if (wanted) {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlayService()
                else vm.setOverlayEnabled(false)
            }
        }

        val actions = HostActions(
            launchGame = ::launchGame,
            setOverlay = ::setOverlay,
            exportConfig = { exportLauncher.launch("nirexion-glassx-config.txt") },
            importConfig = { importLauncher.launch(arrayOf("*/*")) },
            refreshStatus = ::refreshStatus,
            openOverlaySettings = ::openOverlaySettings,
            openAppSettings = ::openAppSettings
        )
        setContent {
            GlassApp(vm, status, actions, pendingRoute) { pendingRoute = null }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingRoute = intent.getStringExtra(EXTRA_ROUTE)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        if (awaitingOverlayGrant) {
            awaitingOverlayGrant = false
            if (status.overlayGranted) setOverlay(true)
            else vm.toast("Overlay permission was not granted, so the panel stays off.")
        }
    }

    private fun refreshStatus() {
        status = HostStatus(
            overlayGranted = Settings.canDrawOverlays(this),
            notificationsGranted = notificationsGranted(),
            gameInstalled = GameLauncher.isInstalled(this),
            gameVersion = GameLauncher.versionName(this)
        )
    }

    private fun notificationsGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun setOverlay(enabled: Boolean) {
        if (!enabled) {
            vm.setOverlayEnabled(false)
            stopService(Intent(this, OverlayService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            awaitingOverlayGrant = true
            vm.toast("The panel needs “Display over other apps”. Opening settings…")
            openOverlaySettings()
            return
        }
        if (!notificationsGranted()) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startOverlay()
    }

    private fun startOverlay() {
        vm.setOverlayEnabled(true)
        startOverlayService()
        vm.toast("Floating panel enabled")
    }

    private fun startOverlayService() {
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: ActivityNotFoundException) {
            vm.toast("Could not open overlay settings. Enable it under system Settings > Apps > NIREXION GLASS X.")
        }
    }

    private fun openAppSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: ActivityNotFoundException) {
            vm.toast("Could not open app settings on this device.")
        }
    }

    private fun launchGame() {
        when (GameLauncher.launch(this)) {
            LaunchResult.LAUNCHED -> Unit
            LaunchResult.NOT_INSTALLED ->
                vm.toast("Free Fire MAX is not installed on this device (package ${GameLauncher.PACKAGE}).")
            LaunchResult.FAILED -> vm.toast("Free Fire MAX is installed but could not be launched.")
        }
    }

    companion object {
        const val EXTRA_ROUTE = "route"
    }
}
