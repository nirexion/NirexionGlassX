package com.nirexion.glassx.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

enum class LaunchResult { LAUNCHED, NOT_INSTALLED, FAILED }

/** Starts Free Fire MAX through its normal launcher entry. No interaction with the game process. */
object GameLauncher {
    const val PACKAGE = "com.dts.freefiremax"

    fun isInstalled(context: Context): Boolean =
        context.packageManager.getLaunchIntentForPackage(PACKAGE) != null

    @Suppress("DEPRECATION")
    fun versionName(context: Context): String? = try {
        context.packageManager.getPackageInfo(PACKAGE, 0).versionName
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    fun launch(context: Context): LaunchResult {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return LaunchResult.NOT_INSTALLED
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            LaunchResult.LAUNCHED
        } catch (e: Exception) {
            LaunchResult.FAILED
        }
    }
}
