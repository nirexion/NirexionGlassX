package com.nirexion.glassx.domain

import java.net.URLDecoder
import java.net.URLEncoder

data class ProfileData(val name: String, val values: SensitivityValues, val notes: String)

data class ConfigBundle(val profiles: List<ProfileData>, val settings: Map<String, String>)

sealed interface DecodeResult {
    data class Success(val bundle: ConfigBundle) : DecodeResult
    data class Failure(val reason: String) : DecodeResult
}

/** Plain-text, human-readable configuration format used for export and import. */
object ConfigCodec {
    const val HEADER = "NIREXIONGLASSX-CONFIG/1"
    const val MAX_CHARS = 262_144
    const val MAX_PROFILES = 100

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String): String? = runCatching { URLDecoder.decode(s, "UTF-8") }.getOrNull()

    fun encode(bundle: ConfigBundle): String = buildString {
        appendLine(HEADER)
        bundle.settings.toSortedMap().forEach { (k, v) -> appendLine("setting.$k=${enc(v)}") }
        bundle.profiles.forEach { p ->
            val v = p.values
            appendLine(
                "profile=${enc(p.name)};${v.general};${v.redDot};${v.scope2x};${v.scope4x};${v.awm};${v.camera};${enc(p.notes)}"
            )
        }
    }

    fun decode(text: String): DecodeResult {
        if (text.length > MAX_CHARS) return DecodeResult.Failure("File is too large to be a NIREXION GLASS X configuration.")
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toList()
        if (lines.firstOrNull() != HEADER) {
            return DecodeResult.Failure("Not a NIREXION GLASS X configuration file (missing header).")
        }
        val profiles = mutableListOf<ProfileData>()
        val settings = linkedMapOf<String, String>()
        for (idx in 1 until lines.size) {
            val line = lines[idx]
            when {
                line.startsWith("profile=") -> {
                    if (profiles.size >= MAX_PROFILES) return DecodeResult.Failure("Too many profiles (limit $MAX_PROFILES).")
                    val parts = line.removePrefix("profile=").split(";")
                    if (parts.size != 8) return DecodeResult.Failure("Line ${idx + 1}: malformed profile entry.")
                    val nums = parts.subList(1, 7).map {
                        it.toIntOrNull() ?: return DecodeResult.Failure("Line ${idx + 1}: sensitivity values must be whole numbers.")
                    }
                    val name = dec(parts[0])?.trim()?.take(40)
                    val notes = dec(parts[7])?.take(500)
                    if (name.isNullOrBlank() || notes == null) return DecodeResult.Failure("Line ${idx + 1}: invalid profile name or notes.")
                    val values = SensitivityValues(nums[0], nums[1], nums[2], nums[3], nums[4], nums[5]).clamped()
                    profiles.add(ProfileData(name, values, notes))
                }
                line.startsWith("setting.") -> {
                    val kv = line.removePrefix("setting.").split("=", limit = 2)
                    if (kv.size != 2) return DecodeResult.Failure("Line ${idx + 1}: malformed setting.")
                    val key = kv[0]
                    val value = dec(kv[1]) ?: return DecodeResult.Failure("Line ${idx + 1}: invalid setting value.")
                    when (key) {
                        "haptics", "particles" ->
                            if (value != "true" && value != "false") return DecodeResult.Failure("Line ${idx + 1}: $key must be true or false.")
                        "difficulty" ->
                            if (Difficulty.values().none { it.name == value }) return DecodeResult.Failure("Line ${idx + 1}: unknown difficulty.")
                        else -> continue
                    }
                    settings[key] = value
                }
            }
        }
        return DecodeResult.Success(ConfigBundle(profiles, settings))
    }
}
