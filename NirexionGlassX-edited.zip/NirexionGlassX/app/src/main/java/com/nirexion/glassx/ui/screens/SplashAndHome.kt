package com.nirexion.glassx.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nirexion.glassx.data.AppSettings
import com.nirexion.glassx.data.ProfileEntity
import com.nirexion.glassx.data.SessionEntity
import com.nirexion.glassx.ui.HostActions
import com.nirexion.glassx.ui.HostStatus
import com.nirexion.glassx.ui.theme.BrandText
import com.nirexion.glassx.ui.theme.GlassCard
import com.nirexion.glassx.ui.theme.GlassColors
import com.nirexion.glassx.ui.theme.NeonButton
import com.nirexion.glassx.ui.theme.SectionTitle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val sc = remember { Animatable(0.6f) }
    val al = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { al.animateTo(1f, tween(900)) }
        launch { sc.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
        launch { progress.animateTo(1f, tween(1900)) }
        delay(2000)
        onDone()
    }
    Column(
        Modifier.fillMaxSize().graphicsLayer { scaleX = sc.value; scaleY = sc.value; alpha = al.value },
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "NIREXION",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(GlassColors.Neon, GlassColors.Ink)),
                fontSize = 40.sp, fontWeight = FontWeight.Black, letterSpacing = 10.sp
            )
        )
        Text(
            "GLASS X",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(GlassColors.NeonAlt, GlassColors.Pink)),
                fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 14.sp
            )
        )
        Spacer(Modifier.height(10.dp))
        Text("Free Fire MAX companion", color = GlassColors.Dim, fontSize = 13.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(28.dp))
        LinearProgressIndicator(
            progress = { progress.value }, modifier = Modifier.width(180.dp),
            color = GlassColors.Neon, trackColor = GlassColors.Neon.copy(alpha = 0.15f)
        )
    }
}

@Composable
private fun StatusRow(label: String, value: String, ok: Boolean?) {
    val color = when (ok) { true -> GlassColors.Good; false -> GlassColors.Warn; null -> GlassColors.Dim }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = GlassColors.Dim, fontSize = 13.sp)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HomeScreen(
    settings: AppSettings,
    profiles: List<ProfileEntity>,
    sessions: List<SessionEntity>,
    status: HostStatus,
    actions: HostActions,
    onNavigate: (String) -> Unit
) {
    val active = profiles.firstOrNull { it.id == settings.activeProfileId }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            BrandText(24)
            Text("Training and sensitivity companion", color = GlassColors.Dim, fontSize = 12.sp)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            SectionTitle("Companion status")
            Spacer(Modifier.height(8.dp))
            StatusRow(
                "Free Fire MAX",
                if (status.gameInstalled) "Installed" + (status.gameVersion?.let { " · v$it" } ?: "") else "Not installed",
                status.gameInstalled
            )
            StatusRow("Overlay permission", if (status.overlayGranted) "Granted" else "Not granted", status.overlayGranted)
            StatusRow("Floating panel", if (settings.overlayEnabled) "On" else "Off", if (settings.overlayEnabled) true else null)
            StatusRow("Active profile", active?.name ?: "None", active != null)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            SectionTitle("Training progress")
            Spacer(Modifier.height(8.dp))
            val best = sessions.maxOfOrNull { it.accuracy }
            val reaction = sessions.filter { it.avgReactionMs > 0f }.map { it.avgReactionMs }.let { if (it.isEmpty()) null else it.average() }
            StatusRow("Sessions", "${sessions.size}", null)
            StatusRow("Best accuracy", best?.let { "%.0f%%".format(it) } ?: "—", null)
            StatusRow("Avg time-to-hit", reaction?.let { "%.0f ms".format(it) } ?: "—", null)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Floating panel", color = GlassColors.Ink, fontWeight = FontWeight.Bold)
                    Text(
                        "Movable, collapsible overlay with this app's metrics and shortcuts.",
                        color = GlassColors.Dim, fontSize = 12.sp
                    )
                }
                Switch(
                    checked = settings.overlayEnabled, onCheckedChange = { actions.setOverlay(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = GlassColors.Neon.copy(alpha = 0.5f), checkedThumbColor = GlassColors.Neon)
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Launch Free Fire MAX", actions.launchGame, Modifier.weight(1f), accent = GlassColors.Good)
            NeonButton("Training Arena", { onNavigate("arena") }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Sensitivity Profiles", { onNavigate("profiles") }, Modifier.weight(1f))
            NeonButton("Diagnostics", { onNavigate("diagnostics") }, Modifier.weight(1f), accent = GlassColors.NeonAlt)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Export config", actions.exportConfig, Modifier.weight(1f), accent = GlassColors.Pink)
            NeonButton("Import config", actions.importConfig, Modifier.weight(1f), accent = GlassColors.Pink)
        }
        Text(
            "This companion runs separately from the game. It cannot read or change Free Fire MAX settings; " +
                "profiles are notes you enter in the game yourself.",
            color = GlassColors.Dim, fontSize = 11.sp
        )
    }
}
