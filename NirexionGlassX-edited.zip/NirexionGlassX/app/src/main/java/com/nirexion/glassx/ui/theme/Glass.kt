package com.nirexion.glassx.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlin.random.Random

object GlassColors {
    val Void = Color(0xFF04060E)
    val Deep = Color(0xFF0A1128)
    val Neon = Color(0xFF35D0FF)
    val NeonAlt = Color(0xFF7A5CFF)
    val Pink = Color(0xFFFF4FD8)
    val Ink = Color(0xFFE8F4FF)
    val Dim = Color(0xFF8FA7C4)
    val Good = Color(0xFF3DFFB0)
    val Warn = Color(0xFFFFC857)
    val Bad = Color(0xFFFF5470)
}

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GlassColors.Neon, secondary = GlassColors.NeonAlt, background = GlassColors.Void,
            surface = GlassColors.Deep, onSurface = GlassColors.Ink, onBackground = GlassColors.Ink,
            onPrimary = GlassColors.Void
        ),
        content = content
    )
}

private class Particle(val x: Float, val y: Float, val r: Float, val speed: Float)

@Composable
fun AuroraBackground(particles: Boolean, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "phase")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "drift")
    val dots = remember { List(38) { Particle(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 2.5f + 0.8f, Random.nextFloat() * 0.6f + 0.2f) } }
    Box(Modifier.fillMaxSize().background(GlassColors.Void)) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.radialGradient(
                    listOf(GlassColors.NeonAlt.copy(alpha = 0.38f), Color.Transparent),
                    center = Offset(size.width * (0.15f + 0.7f * phase), size.height * 0.18f),
                    radius = size.minDimension * 0.95f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(GlassColors.Neon.copy(alpha = 0.30f), Color.Transparent),
                    center = Offset(size.width * (0.9f - 0.7f * phase), size.height * 0.78f),
                    radius = size.minDimension * 1.05f
                )
            )
            if (particles) {
                dots.forEach { p ->
                    val y = (((p.y - drift * p.speed) % 1f) + 1f) % 1f
                    drawCircle(Color.White.copy(alpha = 0.12f + 0.25f * p.speed), p.r * 2f, Offset(p.x * size.width, y * size.height))
                }
            }
        }
        content()
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    var m = modifier
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.04f))))
        .border(1.dp, Brush.linearGradient(listOf(GlassColors.Neon.copy(alpha = 0.9f), GlassColors.NeonAlt.copy(alpha = 0.3f), GlassColors.Neon.copy(alpha = 0.6f))), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun NeonButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, accent: Color = GlassColors.Neon) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(accent.copy(alpha = if (enabled) 0.35f else 0.1f), accent.copy(alpha = 0.1f))))
            .border(1.dp, accent.copy(alpha = if (enabled) 0.9f else 0.3f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) GlassColors.Ink else GlassColors.Dim, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun BrandText(size: Int = 26) {
    Text(
        "NIREXION GLASS X",
        style = TextStyle(
            brush = Brush.horizontalGradient(listOf(GlassColors.Neon, GlassColors.NeonAlt, GlassColors.Pink)),
            fontSize = size.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp
        )
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text.uppercase(), color = GlassColors.Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
}

@Composable
fun GlassSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = GlassColors.Ink, fontSize = 13.sp)
            Text("$value", color = GlassColors.Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.roundToInt()) }, valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = GlassColors.Neon, activeTrackColor = GlassColors.Neon,
                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
            )
        )
    }
}

@Composable
fun GlassTextField(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, singleLine: Boolean = true) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = { Text(label) }, singleLine = singleLine, modifier = modifier,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GlassColors.Neon, unfocusedBorderColor = GlassColors.Neon.copy(alpha = 0.4f),
            focusedTextColor = GlassColors.Ink, unfocusedTextColor = GlassColors.Ink, cursorColor = GlassColors.Neon,
            focusedLabelColor = GlassColors.Neon, unfocusedLabelColor = GlassColors.Dim
        )
    )
}
