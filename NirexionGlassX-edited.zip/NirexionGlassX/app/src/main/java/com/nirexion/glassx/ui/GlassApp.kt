package com.nirexion.glassx.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nirexion.glassx.ui.screens.ArenaScreen
import com.nirexion.glassx.ui.screens.DiagnosticsScreen
import com.nirexion.glassx.ui.screens.HomeScreen
import com.nirexion.glassx.ui.screens.ProfilesScreen
import com.nirexion.glassx.ui.screens.ResultsScreen
import com.nirexion.glassx.ui.screens.SettingsScreen
import com.nirexion.glassx.ui.screens.SplashScreen
import com.nirexion.glassx.ui.theme.AuroraBackground
import com.nirexion.glassx.ui.theme.GlassColors
import com.nirexion.glassx.ui.theme.GlassTheme

private val NAV_ITEMS = listOf(
    Triple("home", "Home", "⌂"),
    Triple("profiles", "Profiles", "◎"),
    Triple("arena", "Arena", "⌖"),
    Triple("results", "Stats", "▤"),
    Triple("settings", "Settings", "⚙")
)

private fun navTo(nav: NavHostController, route: String) {
    nav.navigate(route) {
        popUpTo("home") { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun GlassApp(vm: MainViewModel, status: HostStatus, actions: HostActions, pendingRoute: String?, onRouteConsumed: () -> Unit) {
    val nav = rememberNavController()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var immersive by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    LaunchedEffect(pendingRoute) {
        if (pendingRoute != null) {
            nav.navigate(pendingRoute) {
                popUpTo("splash") { inclusive = true }
                launchSingleTop = true
            }
            onRouteConsumed()
        }
    }

    GlassTheme {
        AuroraBackground(settings.particles) {
            val entry by nav.currentBackStackEntryAsState()
            val route = entry?.destination?.route
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Box(Modifier.weight(1f)) {
                    NavHost(
                        navController = nav, startDestination = "splash", modifier = Modifier.fillMaxSize(),
                        enterTransition = { fadeIn(tween(320)) + scaleIn(initialScale = 0.97f, animationSpec = tween(320)) },
                        exitTransition = { fadeOut(tween(180)) },
                        popEnterTransition = { fadeIn(tween(320)) + scaleIn(initialScale = 0.97f, animationSpec = tween(320)) },
                        popExitTransition = { fadeOut(tween(180)) }
                    ) {
                        composable("splash") {
                            SplashScreen { nav.navigate("home") { popUpTo("splash") { inclusive = true } } }
                        }
                        composable("home") {
                            HomeScreen(settings, profiles, sessions, status, actions) { navTo(nav, it) }
                        }
                        composable("profiles") {
                            ProfilesScreen(settings, profiles, sessions, vm)
                        }
                        composable("arena") {
                            ArenaScreen(
                                settings = settings,
                                onSaveSession = vm::saveSession,
                                onDifficulty = vm::setDifficulty,
                                onImmersive = { immersive = it },
                                onShowResults = { navTo(nav, "results") }
                            )
                        }
                        composable("results") {
                            ResultsScreen(sessions, onClear = vm::clearSessions)
                        }
                        composable("diagnostics") {
                            DiagnosticsScreen(settings, profiles.size, sessions.size, status, actions)
                        }
                        composable("settings") {
                            SettingsScreen(settings, vm, actions) { navTo(nav, it) }
                        }
                    }
                    SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(8.dp))
                }
                if (route != null && route != "splash" && !immersive) {
                    GlassNavBar(route) { navTo(nav, it) }
                }
            }
        }
    }
}

@Composable
private fun GlassNavBar(current: String, onSelect: (String) -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .background(Color.White.copy(alpha = 0.08f), shape)
            .border(1.dp, GlassColors.Neon.copy(alpha = 0.5f), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        NAV_ITEMS.forEach { (r, label, glyph) ->
            val selected = current == r
            Column(
                Modifier.weight(1f)
                    .background(if (selected) GlassColors.Neon.copy(alpha = 0.22f) else Color.Transparent, RoundedCornerShape(16.dp))
                    .clickable { onSelect(r) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(glyph, color = if (selected) GlassColors.Neon else GlassColors.Dim, fontSize = 18.sp)
                Text(label, color = if (selected) GlassColors.Ink else GlassColors.Dim, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
