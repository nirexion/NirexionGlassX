package com.nirexion.glassx

import android.app.Application
import com.nirexion.glassx.data.AppDatabase
import com.nirexion.glassx.data.GlassRepository
import com.nirexion.glassx.data.SettingsRepository

class GlassXApp : Application() {
    val database by lazy { AppDatabase.build(this) }
    val settingsRepository by lazy { SettingsRepository(this) }
    val repository by lazy { GlassRepository(database, settingsRepository) }
}
