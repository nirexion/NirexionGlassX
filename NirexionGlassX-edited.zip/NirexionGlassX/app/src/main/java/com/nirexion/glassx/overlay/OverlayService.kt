package com.nirexion.glassx.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.nirexion.glassx.GlassXApp
import com.nirexion.glassx.MainActivity
import com.nirexion.glassx.R
import com.nirexion.glassx.data.AppSettings
import com.nirexion.glassx.util.GameLauncher
import com.nirexion.glassx.util.LaunchResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Standard Android overlay window owned by this app. It shows this app's own metrics and quick
 * actions. It never reads from, writes to or hooks into any other process.
 */
class OverlayService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())
    private val repo by lazy { (application as GlassXApp).repository }
    private val windowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

    private var root: LinearLayout? = null
    private var creating = false
    private var collapsed = false
    private var bodyView: LinearLayout? = null
    private var toggleView: TextView? = null
    private var profileView: TextView? = null
    private var metricsView: TextView? = null

    private val metricsTick = object : Runnable {
        override fun run() {
            metricsView?.text = buildMetrics()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            disableAndStop()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            scope.launch { repo.settingsRepository.setOverlayEnabled(false) }
            Toast.makeText(this, "Overlay permission missing; panel disabled.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null && !creating) {
            creating = true
            scope.launch {
                buildPanel(repo.settings.first())
                creating = false
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(metricsTick)
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        scope.cancel()
        super.onDestroy()
    }

    private fun disableAndStop() {
        scope.launch {
            repo.settingsRepository.setOverlayEnabled(false)
            stopSelf()
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating panel", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_glass)
            .setContentTitle("NIREXION GLASS X panel is on")
            .setContentText("Floating companion panel is visible.")
            .setContentIntent(open)
            .addAction(0, "Turn off", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(0xFFE8F4FF.toInt())
        textSize = 12f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(0x3335D0FF)
            setStroke(dp(1), 0xFF35D0FF.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun buildPanel(s: AppSettings) {
        collapsed = s.overlayCollapsed
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = s.overlayX
            y = s.overlayY
        }

        val title = TextView(this).apply {
            text = "NIREXION GLASS X"
            setTextColor(0xFF35D0FF.toInt())
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.1f
        }
        val toggle = TextView(this).apply {
            text = if (collapsed) "+" else "–"
            setTextColor(0xFFE8F4FF.toInt())
            textSize = 20f
            setPadding(dp(16), 0, dp(4), 0)
            setOnClickListener { toggleCollapse() }
        }
        toggleView = toggle
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(toggle)
        }

        val profile = TextView(this).apply { setTextColor(0xFFE8F4FF.toInt()); textSize = 12f }
        val metrics = TextView(this).apply { setTextColor(0xFF8FA7C4.toInt()); textSize = 11f }
        profileView = profile
        metricsView = metrics

        fun rowParams() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) }
        val firstButtonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
            addView(chip("Arena") { openRoute("arena") }, rowParams())
            addView(chip("Profiles") { openRoute("profiles") }, rowParams())
        }
        val secondButtonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, 0)
            addView(chip("FF MAX") { launchGame() }, rowParams())
            addView(chip("Diagnostics") { openRoute("diagnostics") }, rowParams())
            addView(chip("Hide") { disableAndStop() }, rowParams())
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(firstButtonRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(secondButtonRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
            addView(profile)
            addView(metrics)
            addView(buttons)
            visibility = if (collapsed) View.GONE else View.VISIBLE
        }
        bodyView = body

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            minimumWidth = dp(230)
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xDD0B1226.toInt(), 0xBB142148.toInt())
            ).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), 0xFF35D0FF.toInt())
            }
            addView(header)
            addView(body)
        }
        panel.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val dm = resources.displayMetrics
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (startX + (e.rawX - touchX)).toInt().coerceIn(0, maxOf(0, dm.widthPixels - v.width))
                        lp.y = (startY + (e.rawY - touchY)).toInt().coerceIn(0, maxOf(0, dm.heightPixels - v.height))
                        windowManager.updateViewLayout(v, lp)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        scope.launch { repo.settingsRepository.setOverlayPosition(lp.x, lp.y) }
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(panel, lp)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not show overlay: ${e.message}", Toast.LENGTH_LONG).show()
            disableAndStop()
            return
        }
        root = panel
        handler.post(metricsTick)
        scope.launch {
            combine(repo.settings, repo.profiles) { st, list -> list.firstOrNull { it.id == st.activeProfileId } }
                .collect { p ->
                    profileView?.text = if (p == null) "No active profile"
                    else "${p.name}: G${p.general} RD${p.redDot} 2x${p.scope2x} 4x${p.scope4x} AWM${p.awm}"
                }
        }
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        bodyView?.visibility = if (collapsed) View.GONE else View.VISIBLE
        toggleView?.text = if (collapsed) "+" else "–"
        scope.launch { repo.settingsRepository.setOverlayCollapsed(collapsed) }
    }

    private fun openRoute(route: String) {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_ROUTE, route)
        )
    }

    private fun launchGame() {
        when (GameLauncher.launch(this)) {
            LaunchResult.LAUNCHED -> Unit
            LaunchResult.NOT_INSTALLED -> Toast.makeText(this, "Free Fire MAX is not installed.", Toast.LENGTH_LONG).show()
            LaunchResult.FAILED -> Toast.makeText(this, "Could not launch Free Fire MAX.", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildMetrics(): String {
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val up = (SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime()) / 1000
        return "This app: heap $usedMb MB · ${Thread.activeCount()} threads · up ${up / 60}m ${up % 60}s"
    }

    companion object {
        const val ACTION_STOP = "com.nirexion.glassx.action.STOP_OVERLAY"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 42
    }
}
