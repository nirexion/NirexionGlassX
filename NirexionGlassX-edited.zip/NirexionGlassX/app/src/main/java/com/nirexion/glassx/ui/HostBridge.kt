package com.nirexion.glassx.ui

data class HostStatus(
    val overlayGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val gameInstalled: Boolean = false,
    val gameVersion: String? = null
)

class HostActions(
    val launchGame: () -> Unit,
    val setOverlay: (Boolean) -> Unit,
    val exportConfig: () -> Unit,
    val importConfig: () -> Unit,
    val refreshStatus: () -> Unit,
    val openOverlaySettings: () -> Unit,
    val openAppSettings: () -> Unit
)
