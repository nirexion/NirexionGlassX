package com.nirexion.glassx.domain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

enum class Difficulty(
    val label: String,
    val radiusDp: Float,
    val speedFracPerSec: Float,
    val spawnIntervalMs: Long,
    val lifetimeMs: Long,
    val maxTargets: Int
) {
    EASY("Easy", 44f, 0.10f, 1100L, 2600L, 3),
    MEDIUM("Medium", 34f, 0.22f, 800L, 1900L, 4),
    HARD("Hard", 24f, 0.40f, 550L, 1300L, 5)
}

class Target(
    val id: Int,
    var x: Float,
    var y: Float,
    val radius: Float,
    var vx: Float,
    var vy: Float,
    val spawnedAtMs: Long
)

data class SessionStats(
    val shots: Int,
    val hits: Int,
    val expired: Int,
    val accuracy: Float,
    val avgReactionMs: Float,
    val bestReactionMs: Float,
    val score: Int
)

/**
 * Pure-Kotlin aim-training simulation. It only manipulates its own virtual targets and never
 * touches any other app or game. "Reaction" is time-to-hit: from target appearance to the tap.
 */
class TrainingEngine(
    val width: Float,
    val height: Float,
    val difficulty: Difficulty,
    density: Float = 1f,
    val durationMs: Long = 60_000L,
    private val random: Random = Random.Default,
    private val startMs: Long = 0L
) {
    private val radius = difficulty.radiusDp * density
    private val active = mutableListOf<Target>()
    private val reactions = mutableListOf<Long>()
    private var nextId = 0
    private var lastUpdateMs = startMs
    private var lastSpawnMs = startMs - difficulty.spawnIntervalMs

    val targets: List<Target> get() = active

    var shots = 0
        private set
    var hits = 0
        private set
    var expired = 0
        private set
    var score = 0
        private set

    fun isFinished(nowMs: Long): Boolean = nowMs - startMs >= durationMs

    fun remainingMs(nowMs: Long): Long = (durationMs - (nowMs - startMs)).coerceAtLeast(0L)

    fun update(nowMs: Long) {
        val dt = (nowMs - lastUpdateMs).coerceAtLeast(0L) / 1000f
        lastUpdateMs = nowMs
        val iter = active.iterator()
        while (iter.hasNext()) {
            val t = iter.next()
            if (nowMs - t.spawnedAtMs >= difficulty.lifetimeMs) {
                iter.remove()
                expired++
            } else {
                move(t, dt)
            }
        }
        if (!isFinished(nowMs) &&
            active.size < difficulty.maxTargets &&
            nowMs - lastSpawnMs >= difficulty.spawnIntervalMs
        ) {
            spawn(nowMs)
        }
    }

    /** Registers a tap. Returns true when it hit a target. Taps after the session ends are ignored. */
    fun tap(x: Float, y: Float, nowMs: Long): Boolean {
        if (isFinished(nowMs)) return false
        shots++
        val hit = active
            .filter { hypot(it.x - x, it.y - y) <= it.radius }
            .minByOrNull { hypot(it.x - x, it.y - y) } ?: return false
        active.remove(hit)
        hits++
        val reaction = (nowMs - hit.spawnedAtMs).coerceAtLeast(0L)
        reactions.add(reaction)
        score += 100 + ((1000L - reaction).coerceAtLeast(0L) / 10L).toInt()
        return true
    }

    fun stats(): SessionStats = SessionStats(
        shots = shots,
        hits = hits,
        expired = expired,
        accuracy = if (shots == 0) 0f else hits * 100f / shots,
        avgReactionMs = if (reactions.isEmpty()) 0f else reactions.average().toFloat(),
        bestReactionMs = reactions.minOrNull()?.toFloat() ?: 0f,
        score = score
    )

    private fun move(t: Target, dt: Float) {
        t.x += t.vx * dt
        t.y += t.vy * dt
        val maxX = max(radius, width - radius)
        val maxY = max(radius, height - radius)
        if (t.x < radius) { t.x = radius; t.vx = abs(t.vx) } else if (t.x > maxX) { t.x = maxX; t.vx = -abs(t.vx) }
        if (t.y < radius) { t.y = radius; t.vy = abs(t.vy) } else if (t.y > maxY) { t.y = maxY; t.vy = -abs(t.vy) }
    }

    private fun spawn(nowMs: Long) {
        val maxX = max(radius, width - radius)
        val maxY = max(radius, height - radius)
        val x = radius + random.nextFloat() * (maxX - radius)
        val y = radius + random.nextFloat() * (maxY - radius)
        val angle = random.nextFloat() * (2f * PI.toFloat())
        val speed = difficulty.speedFracPerSec * width
        active.add(Target(nextId++, x, y, radius, cos(angle) * speed, sin(angle) * speed, nowMs))
        lastSpawnMs = nowMs
    }
}
