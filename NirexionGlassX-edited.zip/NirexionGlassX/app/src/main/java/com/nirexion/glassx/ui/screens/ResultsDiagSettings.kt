package com.nirexion.glassx.ui.screens

import android.os.Build
import android.os.Debug
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nirexion.glassx.data.AppSettings
import com.nirexion.glassx.data.SessionEntity
import com.nirexion.glassx.ui.HostActions
import com.nirexion.glassx.ui.HostStatus
import com.nirexion.glassx.ui.MainViewModel
import com.nirexion.glassx.ui.theme.GlassCard
import com.nirexion.glassx.ui.theme.GlassColors
import com.nirexion.glassx.ui.theme.NeonButton
import com.nirexion.glassx.ui.theme.SectionTitle
import java.text.DateFormat
import java.util.Date

@Composable
private fun LineChart(values: List<Float>, color: Color, modifier: Modifier = Modifier.fillMaxWidth().height(100.dp)) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val maxV = values.max().coerceAtLeast(1f)
        val stepX = size.width / (values.size - 1)
        val pts = values.mapIndexed { i, v -> Offset(i * stepX, size.height * 0.95f - (v / maxV) * size.height * 0.9f) }
        val path = Path()
        pts.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
        drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        pts.forEach { drawCircle(color, 4.dp.toPx(), it) }
    }
}

@Composable
fun ResultsScreen(sessions: List<SessionEntity>, onClear: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    val chrono = sessions.take(20).reversed()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Results & progress", color = GlassColors.Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
        if (sessions.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) { Text("No sessions yet. Play the training arena to see progress here.", color = GlassColors.Dim) }
        } else {
            val recent = sessions.take(5)
            val prev = sessions.drop(5).take(5)
            val trend = if (prev.isEmpty()) null else recent.map { it.accuracy }.average() - prev.map { it.accuracy }.average()
            GlassCard(Modifier.fillMaxWidth()) {
                SectionTitle("Summary")
                Spacer(Modifier.height(8.dp))
                Line("Sessions", "${sessions.size}")
                Line("Average accuracy", "%.0f%%".format(sessions.map { it.accuracy }.average()))
                Line("Best score", "${sessions.maxOf { it.score }}")
                Line("Accuracy trend (last 5 vs previous 5)", trend?.let { "%+.1f pts".format(it) } ?: "needs 6+ sessions")
            }
            GlassCard(Modifier.fillMaxWidth()) {
                SectionTitle("Accuracy % (last ${chrono.size})")
                Spacer(Modifier.height(8.dp))
                LineChart(chrono.map { it.accuracy }, GlassColors.Neon)
            }
            GlassCard(Modifier.fillMaxWidth()) {
                SectionTitle("Avg time-to-hit ms (lower is faster)")
                Spacer(Modifier.height(8.dp))
                LineChart(chrono.map { it.avgReactionMs }, GlassColors.Pink)
            }
            val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
            sessions.take(30).forEach { s ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${s.difficulty.lowercase().replaceFirstChar { it.uppercase() }} · ${s.score} pts", color = GlassColors.Ink, fontWeight = FontWeight.Bold)
                        Text(fmt.format(Date(s.startedAt)), color = GlassColors.Dim, fontSize = 12.sp)
                    }
                    Text(
                        "%.0f%% accuracy · %d/%d hits · %.0f ms avg".format(s.accuracy, s.hits, s.shots, s.avgReactionMs),
                        color = GlassColors.Dim, fontSize = 12.sp
                    )
                }
            }
            NeonButton("Clear history", { confirm = true }, Modifier.fillMaxWidth(), accent = GlassColors.Bad)
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = GlassColors.Deep,
            title = { Text("Clear all history?", color = GlassColors.Ink) },
            text = { Text("All saved training sessions will be deleted.", color = GlassColors.Dim) },
            confirmButton = { TextButton({ onClear(); confirm = false }) { Text("Clear", color = GlassColors.Bad) } },
            dismissButton = { TextButton({ confirm = false }) { Text("Cancel", color = GlassColors.Neon) } }
        )
    }
}

@Composable
private fun Line(label: String, value: String, ok: Boolean? = null) {
    val c = when (ok) { true -> GlassColors.Good; false -> GlassColors.Warn; null -> GlassColors.Ink }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = GlassColors.Dim, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = c, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Suppress("DEPRECATION")
@Composable
fun DiagnosticsScreen(settings: AppSettings, profileCount: Int, sessionCount: Int, status: HostStatus, actions: HostActions) {
    val context = LocalContext.current
    var fps by remember { mutableFloatStateOf(0f) }
    var heapMb by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var frames = 0
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            frames++
            if (now - last >= 1_000_000_000L) {
                fps = frames * 1e9f / (now - last)
                frames = 0
                last = now
                val rt = Runtime.getRuntime()
                heapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
            }
        }
    }
    val rt = Runtime.getRuntime()
    val refresh = (context.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Diagnostics", color = GlassColors.Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
        GlassCard(Modifier.fillMaxWidth()) {
            SectionTitle("This app's performance")
            Spacer(Modifier.height(8.dp))
            Line("UI frame rate", "%.0f fps".format(fps))
            Line("Display refresh rate", "%.0f Hz".format(refresh))
            Line("Java heap used / max", "$heapMb / ${rt.maxMemory() / (1024 * 1024)} MB")
            Line("Native heap allocated", "${Debug.getNativeHeapAllocatedSize() / (1024 * 1024)} MB")
            Line("CPU cores", "${rt.availableProcessors()}")
        }
        GlassCard(Modifier.fillMaxWidth()) {
            SectionTitle("Device")
            Spacer(Modifier.height(8.dp))
            Line("Model", "${Build.MANUFACTURER} ${Build.MODEL}")
            Line("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            Line("Screen density", "%.2fx".format(context.resources.displayMetrics.density))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            SectionTitle("Integration checks")
            Spacer(Modifier.height(8.dp))
            Line("Free Fire MAX", if (status.gameInstalled) "Installed" + (status.gameVersion?.let { " · v$it" } ?: "") else "Not installed", status.gameInstalled)
            Line("Overlay permission", if (status.overlayGranted) "Granted" else "Not granted", status.overlayGranted)
            Line("Notification permission", if (status.notificationsGranted) "Granted" else "Not granted", status.notificationsGranted)
            Line("Floating panel setting", if (settings.overlayEnabled) "On" else "Off")
            Line("Saved profiles", "$profileCount")
            Line("Saved sessions", "$sessionCount")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Re-check", actions.refreshStatus, Modifier.weight(1f))
            NeonButton("Overlay settings", actions.openOverlaySettings, Modifier.weight(1f), accent = GlassColors.NeonAlt)
        }
        NeonButton("App settings", actions.openAppSettings, Modifier.fillMaxWidth(), accent = GlassColors.Dim)
    }
}

@Composable
fun SettingsScreen(settings: AppSettings, vm: MainViewModel, actions: HostActions, onNavigate: (String) -> Unit) {
    val sw = SwitchDefaults.colors(checkedTrackColor = GlassColors.Neon.copy(alpha = 0.5f), checkedThumbColor = GlassColors.Neon)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", color = GlassColors.Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("Floating panel", "Needs the display-over-apps permission", settings.overlayEnabled, sw) { actions.setOverlay(it) }
            SwitchRow("Haptic feedback", "Vibration on arena hits", settings.haptics, sw) { vm.setHaptics(it) }
            SwitchRow("Background particles", "Animated particles behind the UI", settings.particles, sw) { vm.setParticles(it) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Export config", actions.exportConfig, Modifier.weight(1f), accent = GlassColors.Pink)
            NeonButton("Import config", actions.importConfig, Modifier.weight(1f), accent = GlassColors.Pink)
        }
        NeonButton("Diagnostics", { onNavigate("diagnostics") }, Modifier.fillMaxWidth(), accent = GlassColors.NeonAlt)
        GlassCard(Modifier.fillMaxWidth()) {
            SectionTitle("About & limitations")
            Spacer(Modifier.height(8.dp))
            Text(
                "NIREXION GLASS X 1.0.0\n\n" +
                    "• Runs as a separate app. It does not inject code into, read memory from, or change Free Fire MAX.\n" +
                    "• It cannot change the game's settings. Sensitivity profiles are notes you apply manually.\n" +
                    "• The arena is a standalone simulation; its numbers do not measure in-game performance.\n" +
                    "• The panel's metrics describe this app only, not the game.\n" +
                    "• Some devices or the game may hide or restrict overlay windows.\n" +
                    "• Not affiliated with or endorsed by Garena.",
                color = GlassColors.Dim, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, colors: androidx.compose.material3.SwitchColors, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = GlassColors.Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, color = GlassColors.Dim, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = colors)
    }
}
