package com.nirexion.glassx.ui

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nirexion.glassx.GlassXApp
import com.nirexion.glassx.data.AppSettings
import com.nirexion.glassx.data.ImportOutcome
import com.nirexion.glassx.data.ProfileEntity
import com.nirexion.glassx.data.SessionEntity
import com.nirexion.glassx.domain.ConfigCodec
import com.nirexion.glassx.domain.Difficulty
import com.nirexion.glassx.domain.SensitivityValues
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as GlassXApp).repository

    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val profiles: StateFlow<List<ProfileEntity>> =
        repo.profiles.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sessions: StateFlow<List<SessionEntity>> =
        repo.sessions.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages = _messages.asSharedFlow()

    fun toast(msg: String) { _messages.tryEmit(msg) }

    fun setOverlayEnabled(v: Boolean) { viewModelScope.launch { repo.settingsRepository.setOverlayEnabled(v) } }
    fun setHaptics(v: Boolean) { viewModelScope.launch { repo.settingsRepository.setHaptics(v) } }
    fun setParticles(v: Boolean) { viewModelScope.launch { repo.settingsRepository.setParticles(v) } }
    fun setDifficulty(d: Difficulty) { viewModelScope.launch { repo.settingsRepository.setDifficulty(d) } }
    fun setActiveProfile(id: Long) {
        viewModelScope.launch {
            repo.settingsRepository.setActiveProfile(id)
            toast("Active profile updated")
        }
    }

    fun saveProfile(id: Long, name: String, values: SensitivityValues, notes: String) {
        viewModelScope.launch {
            val c = values.clamped()
            val newId = repo.saveProfile(
                ProfileEntity(
                    id = id, name = name.trim(), general = c.general, redDot = c.redDot, scope2x = c.scope2x,
                    scope4x = c.scope4x, awm = c.awm, camera = c.camera, notes = notes.trim(),
                    updatedAt = System.currentTimeMillis()
                )
            )
            if (settings.value.activeProfileId < 0) repo.settingsRepository.setActiveProfile(newId)
            toast("Profile “${name.trim()}” saved")
        }
    }

    fun deleteProfile(id: Long) {
        viewModelScope.launch {
            repo.deleteProfile(id)
            toast("Profile deleted")
        }
    }

    fun saveSession(s: SessionEntity) { viewModelScope.launch { repo.saveSession(s) } }

    fun clearSessions() {
        viewModelScope.launch {
            repo.clearSessions()
            toast("Training history cleared")
        }
    }

    fun exportTo(resolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = repo.exportText()
                    val out = resolver.openOutputStream(uri, "wt") ?: error("Could not open the file for writing")
                    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
            }
            toast(if (result.isSuccess) "Configuration exported" else "Export failed: ${result.exceptionOrNull()?.message}")
        }
    }

    fun importFrom(resolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = resolver.openInputStream(uri)?.use { readLimited(it, ConfigCodec.MAX_CHARS * 4) }
                    bytes?.toString(Charsets.UTF_8)
                }.getOrNull()
            }
            if (text == null) {
                toast("Import failed: file could not be read or is too large")
                return@launch
            }
            when (val r = repo.importText(text)) {
                is ImportOutcome.Imported -> toast("Imported ${r.profiles} profile(s) and settings")
                is ImportOutcome.Failed -> toast("Import failed: ${r.reason}")
            }
        }
    }

    private fun readLimited(stream: InputStream, maxBytes: Int): ByteArray? {
        val buf = ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        var total = 0
        while (true) {
            val n = stream.read(chunk)
            if (n < 0) break
            total += n
            if (total > maxBytes) return null
            buf.write(chunk, 0, n)
        }
        return buf.toByteArray()
    }
}
