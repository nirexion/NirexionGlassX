package com.nirexion.glassx.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nirexion.glassx.domain.Difficulty
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class AppSettings(
    val overlayEnabled: Boolean = false,
    val overlayCollapsed: Boolean = false,
    val overlayX: Int = 24,
    val overlayY: Int = 240,
    val activeProfileId: Long = -1L,
    val haptics: Boolean = true,
    val particles: Boolean = true,
    val difficulty: Difficulty = Difficulty.MEDIUM
)

private val Context.glassDataStore: DataStore<Preferences> by preferencesDataStore(name = "glassx_settings")

class SettingsRepository(private val context: Context) {
    private object K {
        val overlayEnabled = booleanPreferencesKey("overlay_enabled")
        val overlayCollapsed = booleanPreferencesKey("overlay_collapsed")
        val overlayX = intPreferencesKey("overlay_x")
        val overlayY = intPreferencesKey("overlay_y")
        val activeProfile = longPreferencesKey("active_profile")
        val haptics = booleanPreferencesKey("haptics")
        val particles = booleanPreferencesKey("particles")
        val difficulty = stringPreferencesKey("difficulty")
    }

    val settings: Flow<AppSettings> = context.glassDataStore.data.map { p ->
        val d = AppSettings()
        AppSettings(
            overlayEnabled = p[K.overlayEnabled] ?: d.overlayEnabled,
            overlayCollapsed = p[K.overlayCollapsed] ?: d.overlayCollapsed,
            overlayX = p[K.overlayX] ?: d.overlayX,
            overlayY = p[K.overlayY] ?: d.overlayY,
            activeProfileId = p[K.activeProfile] ?: d.activeProfileId,
            haptics = p[K.haptics] ?: d.haptics,
            particles = p[K.particles] ?: d.particles,
            difficulty = Difficulty.values().firstOrNull { it.name == p[K.difficulty] } ?: d.difficulty
        )
    }

    private suspend fun update(block: (MutablePreferences) -> Unit) {
        context.glassDataStore.edit { block(it) }
    }

    suspend fun setOverlayEnabled(v: Boolean) = update { it[K.overlayEnabled] = v }
    suspend fun setOverlayCollapsed(v: Boolean) = update { it[K.overlayCollapsed] = v }
    suspend fun setOverlayPosition(x: Int, y: Int) = update { it[K.overlayX] = x; it[K.overlayY] = y }
    suspend fun setActiveProfile(id: Long) = update { it[K.activeProfile] = id }
    suspend fun setHaptics(v: Boolean) = update { it[K.haptics] = v }
    suspend fun setParticles(v: Boolean) = update { it[K.particles] = v }
    suspend fun setDifficulty(v: Difficulty) = update { it[K.difficulty] = v.name }
}
