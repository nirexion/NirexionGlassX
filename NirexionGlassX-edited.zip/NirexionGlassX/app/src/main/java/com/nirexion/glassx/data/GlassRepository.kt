package com.nirexion.glassx.data

import com.nirexion.glassx.domain.ConfigBundle
import com.nirexion.glassx.domain.ConfigCodec
import com.nirexion.glassx.domain.DecodeResult
import com.nirexion.glassx.domain.Difficulty
import com.nirexion.glassx.domain.ProfileData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

sealed interface ImportOutcome {
    data class Imported(val profiles: Int) : ImportOutcome
    data class Failed(val reason: String) : ImportOutcome
}

class GlassRepository(private val db: AppDatabase, val settingsRepository: SettingsRepository) {
    val settings: Flow<AppSettings> = settingsRepository.settings
    val profiles: Flow<List<ProfileEntity>> = db.profileDao().observeAll()
    val sessions: Flow<List<SessionEntity>> = db.sessionDao().observeAll()

    suspend fun saveProfile(p: ProfileEntity): Long = db.profileDao().upsert(p)

    suspend fun deleteProfile(id: Long) {
        db.profileDao().delete(id)
        if (settings.first().activeProfileId == id) settingsRepository.setActiveProfile(-1L)
    }

    suspend fun saveSession(s: SessionEntity) = db.sessionDao().insert(s)

    suspend fun clearSessions() = db.sessionDao().deleteAll()

    suspend fun exportText(): String {
        val s = settings.first()
        val data = profiles.first().map { ProfileData(it.name, it.toValues(), it.notes) }
        val map = mapOf(
            "haptics" to s.haptics.toString(),
            "particles" to s.particles.toString(),
            "difficulty" to s.difficulty.name
        )
        return ConfigCodec.encode(ConfigBundle(data, map))
    }

    suspend fun importText(text: String): ImportOutcome {
        return when (val r = ConfigCodec.decode(text)) {
            is DecodeResult.Failure -> ImportOutcome.Failed(r.reason)
            is DecodeResult.Success -> {
                val now = System.currentTimeMillis()
                r.bundle.profiles.forEach { p ->
                    val v = p.values
                    db.profileDao().upsert(
                        ProfileEntity(
                            name = p.name, general = v.general, redDot = v.redDot, scope2x = v.scope2x,
                            scope4x = v.scope4x, awm = v.awm, camera = v.camera, notes = p.notes, updatedAt = now
                        )
                    )
                }
                r.bundle.settings["haptics"]?.let { settingsRepository.setHaptics(it.toBoolean()) }
                r.bundle.settings["particles"]?.let { settingsRepository.setParticles(it.toBoolean()) }
                r.bundle.settings["difficulty"]?.let { n ->
                    Difficulty.values().firstOrNull { it.name == n }?.let { settingsRepository.setDifficulty(it) }
                }
                ImportOutcome.Imported(r.bundle.profiles.size)
            }
        }
    }
}
