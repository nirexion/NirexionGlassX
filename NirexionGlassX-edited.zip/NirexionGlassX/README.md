# NIREXION GLASS X

NIREXION GLASS X is an Android gaming companion with a Liquid Glass UI, standalone aim-training arena,
sensitivity profiles, a movable floating quick-action panel, config export/import, and device/app diagnostics.
It runs as a separate app and does not inject code into, modify, or manipulate Free Fire MAX or any other game process.

The floating panel now provides quick routes to Arena, Profiles, Diagnostics, and the Free Fire MAX launcher.

## Build
- Android Studio Koala (2024.1) or newer, JDK 17, Android SDK 34.
- Open this folder, let Gradle sync, then Build > Build APK, or:
  `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- Unit tests: `./gradlew testDebugUnitTest`
- If `./gradlew` is missing, run `gradle wrapper --gradle-version 8.7` once (the wrapper jar/scripts are not bundled).

## Install
`adb install -r app/build/outputs/apk/debug/app-debug.apk` or copy the APK to the phone.
Android 8.0+ (API 26).

## Limitations
See Settings > About & limitations in the app.


## Cloud build from an Android phone
1. Upload the contents of this project folder to a GitHub repository (include the hidden `.github` folder).
2. Open the repository's **Actions** tab and run **Build NIREXION GLASS X APK**.
3. After the workflow completes successfully, download the `NIREXION-GLASS-X-debug-apk` artifact from the run summary.
4. Extract the artifact ZIP to get `app-debug.apk`.

The workflow builds with JDK 17 and Gradle 8.7, runs unit tests, and uploads the debug APK. A successful build has not been verified until the workflow completes successfully.
